<section class="overflow-hidden py-5 our-clients"  style="background:#f6f6f6">
    <div class="containerFull">
        <h4 class="heading text-center fontHeading fontWeight700 letterSpacing-2 text_secondary" data-aos="fade-up">
            Our <span class="text-color1">Clients

            </span>
        </h4>

        <div class="mt-5" data-aos="fade-up">
            <div class="clients clientSlider">
                <div class="col-lg-2">
                    <div class="itemReview">
                        <img src="images/our-clients/c-1.png">
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="itemReview">
                        <img src="images/our-clients/c-2.png">
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="itemReview">
                        <img src="images/our-clients/c-1.png">
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="itemReview">
                        <img src="images/our-clients/c-2.png">
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="itemReview">
                        <img src="images/our-clients/c-1.png">
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="itemReview">
                        <img src="images/our-clients/c-2.png">
                    </div>
                </div>
            </div>
        </div>
    </div>

</section>